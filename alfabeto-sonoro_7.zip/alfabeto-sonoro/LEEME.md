# Alfabeto Sonoro / Conciencia Fonológica — instrucciones

## Estructura del proyecto

```
alfabeto-sonoro/
├── index.html              ← la app (liviana, usa las imágenes de la carpeta)
├── index-standalone.html   ← copia con TODAS las imágenes incrustadas
│                              (solo para probar tocándola en el chat de Claude,
│                              no hace falta subir esta a GitHub)
├── images/                  ← todas las fotos/dibujos de las actividades
├── sounds/                  ← sonidos de las letras (Nivel 4) — pendiente
└── ayuda/                   ← audios de ayuda (palabra estirada) — pendiente
```

## Publicar en GitHub Pages

1. Entrá a **github.com**, creá un repositorio (por ejemplo `alfabeto-sonoro`), público.
2. Subí el contenido de esta carpeta **excepto** `index-standalone.html`:
   - `index.html`
   - la carpeta `images/` completa
   - la carpeta `sounds/` (aunque esté vacía por ahora, para cuando grabes)
3. En el repo: **Settings → Pages** → Branch: `main`, carpeta `/ (root)` → Guardar.
4. En un par de minutos te da un link (`tunombre.github.io/alfabeto-sonoro`), listo para usar en cualquier compu o celular.

## Para seguir agregando cosas

- Cuando grabes sonidos o subas más imágenes, agregalos a las carpetas `sounds/` o `images/` con el nombre exacto de la palabra, y volvés a subir esos archivos al repositorio — no hace falta tocar el código.
- Si en algún momento querés volver a probar la app tocándola en el chat de Claude (sin publicarla), usá `index-standalone.html`, que tiene todo incrustado en un solo archivo.
